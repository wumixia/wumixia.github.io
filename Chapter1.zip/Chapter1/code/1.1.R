## 1.1节例题


################## 例1.1.4 ##################
install.packages("UsingR")
library(UsingR)
data(father.son)

## like cover of Freedman, Pisani, and Purves
plot(sheight ~ fheight, data=father.son,bty="l",pch=20)
abline(a=0,b=1,lty=2,lwd=2) # # 这条线表示"儿子身高=父亲身高"的理想情况
abline(lm(sheight ~ fheight, data=father.son),lty=1,lwd=2, col = "red") # # 添加回归线
mean(father.son$sheight)
mean(father.son$fheight)
reg<-lm(sheight ~ fheight, data=father.son)
summary(reg)

#更多分析https://datarepository.wolframcloud.com/resources/Galton-Parent-and-Child-Height-Data/
