## 8.5节例题


################## 例8.5.1 ##################

library(car)
data <- read.table("/Users/macbook/Desktop/线性模型例题/Chapter8/data/例8.5.1.txt",header=TRUE )
A<-factor(gl(4,2,32))
B<-factor(gl(4,8,32))
yreg<-lm(y~A+B+Z, data=data)  
summary(yreg)
Anova(yreg, type=2)  ##协方差分析表 type=2 适合无交互效应的情形

#Anova Table (Type II tests)

#Response: y
#          Sum Sq Df F value    Pr(>F)    
#A         13.035  3  2.7884   0.06237 .  
#B          5.878  3  1.2574   0.31124    
#Z         63.632  1 40.8349 1.316e-06 ***
#Residuals 37.399 24                      
#---
#Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1



yreg1<-lm(y~B+Z, data=data) #  Residuals 27  50.434   1.868   
anova(yreg1)
F1=24/3*(50.434 -37.399)/37.399
p=1-pf(F1,3,24)
c(F1, p)

yreg2<-lm(y~A+Z, data=data) ## Residuals 27 43.277   1.603 
summary(yreg2)
Anova(yreg2,type=2)

F2=24/3*(43.277 -37.399)/37.399
p=1-pf(F2,3,24)
c(F2, p)

AnB<- aov(y~B, data=data)
AnA<- aov(y~A, data=data)
summary(AnA)
summary(AnB)

yreg3<-lm(y~B+A, data=data)
anova(yreg3)  ## 残差101.031  4.0412 

1-pf(1.257,3,24)
1-pf(2.789,3,24)

yreg4<-lm(y~Z , data=data)
summary(yreg4)
anova(yreg4)

F4= 9* (58.592-43.277)/43.277
c(qf(0.95, 3,27), 1-pf(F4, 3,27))



### 作散点图 
A<-factor(gl(4,2,32))
B<-factor(gl(4,8,32))

data3 <-cbind(data,A,B)

A1B1<-subset(data3, data3$A==1 & data3$B==1) 

A1<-subset(data3, data3$A==1) 
A2<-subset(data3, data3$A==2) 
A3<-subset(data3, data3$A==3) 
A4<-subset(data3, data3$A==4)


B1<-subset(data3, data3$B==1) 
B2<-subset(data3, data3$B==2) 
B3<-subset(data3, data3$B==3) 
B4<-subset(data3, data3$B==4)


## 图8.5.1
## 绘制第一个箱线图 (y ~ A)
par(ann = FALSE, mar = c(5, 5, 4, 2) + 0.3)
boxplot(y ~ A, col = "skyblue", data = data,
        yaxt = 'n',  # 隐藏默认y轴刻度
        xlab = "", ylab = "")
axis(side = 2, at = seq(70, 78, by = 2), las = 1) # 添加y轴刻度
title(main = expression("因子"~italic(A)~"各水平下"~italic(Y)~"的Box图"),
      ylab = expression(italic(Y)),  # y轴标签设为斜体
      xlab = expression(italic(A)), # x轴标签设为斜体
      line = 2.5)  # 调整标签与坐标轴的距离 # 分别调整主标题、y轴、x轴标签的距离

# 绘制第二个箱线图 (y ~ B)
boxplot(y ~ B, col = "skyblue", data = data,
        yaxt = 'n',  # 隐藏默认y轴刻度
        xlab = "", ylab = "")
axis(side = 2, at = seq(70, 78, by = 2), las = 1) # 添加y轴刻度
# 添加标题和标签（含斜体）
title(main = expression("因子"~italic(B)~"各水平下"~italic(Y)~"的Box图"),
      ylab = expression(italic(Y)),  # y轴标签设为斜体
      xlab = expression(italic(B)),  # x轴标签设为斜体
      line = 2.5)  # 分别调整主标题、y轴、x轴标签的距离



plot(A1$Z, A1$y,lwd=3, bty = 'l',col='black', xaxt='n', yaxt='n', xlab = "", ylab = "", xlim=c(49,50.5), ylim=c(68,80), pch=6)
par(new=TRUE)
plot(A2$Z, A2$y,lwd=3, bty = 'l',col='red', xaxt='n', yaxt='n', xlab = "", ylab = "", xlim=c(49,50.5), ylim=c(68,80), pch=15)
par(new=TRUE)
plot(A3$Z, A3$y,lwd=3, bty = 'l',col='green', xaxt='n', yaxt='n', xlab = "", ylab = "", xlim=c(49,50.5), ylim=c(68,80), pch=16)
par(new=TRUE)
plot(A4$Z, A4$y,lwd=3, bty = 'l',col='purple', xaxt='n', yaxt='n', xlab = "", ylab = "", xlim=c(49,50.5), ylim=c(68,80), pch=17)
text(50.5,68, expression(italic(paste(Z))), cex=1)
text(49,80, expression(italic(paste(Y))), cex=1)
legend(list(x=50.2,y=73), #"topright",                                    #图例位置为右上角
       legend = c(expression(italic(A1)), 
                  expression(italic(A2)), 
                  expression(italic(A3)), 
                  expression(italic(A4))),        #图例内容
       col=c("black","red" ,'green','purple'),    #图例颜色
       pch=c(6,15,16,17),bty = 'l'
)   
title(main = expression("因子"~italic(A)~"各水平下"~(italic(paste(Z, ", ", Y)))~"的散点图"))




plot(B1$Z, B1$y,lwd=3, bty = 'l',col='black' , xaxt='n', yaxt='n', xlab = "", ylab = "", xlim=c(49,50.5), ylim=c(68,80), pch=6)
par(new=TRUE)
plot(B2$Z, B2$y,lwd=3, bty = 'l',col='red', xaxt='n', yaxt='n', xlab = "", ylab = "", xlim=c(49,50.5), ylim=c(68,80), pch=15)
par(new=TRUE)
plot(B3$Z, B3$y,lwd=3, bty = 'l',col='green', xaxt='n', yaxt='n', xlab = "", ylab = "", xlim=c(49,50.5), ylim=c(68,80), pch=16)
par(new=TRUE)
plot(B4$Z, B4$y,lwd=3, bty = 'l',col='purple', xaxt='n', yaxt='n', xlab = "", ylab = "", xlim=c(49,50.5), ylim=c(68,80), pch=17)
text(50.5,68, expression(italic(paste(Z))), cex=1)
text(49,80, expression(italic(paste(Y))), cex=1)
legend(list(x=50.2,y=73), #"topright",             #图例位置为右上角
       legend=c(expression(italic(B1)), 
                expression(italic(B2)), 
                expression(italic(B3)), 
                expression(italic(B4))),        #图例内容
       col=c("black","red" ,'green','purple'),              #图例颜色
       pch=c(6,15,16,17))   
title(main = expression("因子"~italic(B)~"各水平下"~(italic(paste(Z, ", ", Y)))~"的散点图"))







################## 8.5.2节 ##################

yreg2<-lm(y~A+Z, data=data) ## Residuals 27 43.277   1.603 
summary(yreg2)
Anova(yreg2,type=2)


## 置信区间 
yreg2<-lm(y~A+Z, data=data)
lmResults<-summary(yreg2)
n<- length(data$y); alpha=0.05
s<-round(lmResults$sigma,3); ##残差标准差1.266 
coef<-yreg2$coefficients      #回归系数
C<-cbind(c(rep(0,6)), c(-2,-1,-1,1,1,0), c(-1,-2,-1,-1,0, 1),c(-1,-1,-2,0,-1,-1), c(rep(0,6)) )
dalta<-round(C%*% coef,3)    ##水平对照

o1<-c(rep(1,n)) 
I2<-c(rep(0,n)); I2[A==1]<- -1; I2[A==2]<- 1;
I3<-c(rep(0,n)); I3[A==1]<- -1; I3[A==3]<- 1;
I4<-c(rep(0,n)); I4[A==1]<- -1; I4[A==4]<- 1;
W=cbind(o1,I2, I3, I4, data$Z) ###模型系数矩阵
D<-round(solve(t(W)%*%W),4) ##(W'W)^{-1}
sqtvar<-round(s* sqrt(diag(C%*%D%*%t(C))),3) ##对照的标准差
f=n-ncol(W) 

# 两两水平对照的置信区间
daltaL<-dalta-sqtvar*qt(1-alpha/2, f)
daltaR<-dalta+sqtvar*qt(1-alpha/2, f)

# Scheffe同时置信区间 
daltaSL<-dalta-sqtvar*sqrt(3*qf(1-alpha, 3,f))
daltaSR<-dalta+sqtvar*sqrt(3*qf(1-alpha, 3,f))

# Bonferroni同时置信区间 
daltaBL<-dalta-sqtvar*qt(1-alpha/12, f)
daltaBR<-dalta+sqtvar*qt(1-alpha/12, f)

Confi<-cbind(dalta, daltaL,daltaR,daltaSL,daltaSR, daltaBL,daltaBR)
round(Confi,3)

# 6对对照的右边检验的拒绝域左端点
daltaR0<-sqtvar*qt(1-alpha, f) #右边检验的拒绝域

