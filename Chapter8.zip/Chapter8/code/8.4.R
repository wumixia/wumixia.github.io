## 8.4节例题


################## 例8.4.1 ##################
data <- read.table("/Users/macbook/Desktop/线性模型例题/Chapter8/data/例8.4.1.txt", ,header=TRUE)
library(car)
A<-factor(c(rep(1,5),rep(2,5),rep(3,5)))
yreg<-lm(Y~A+Z, data=data) ## 协方差模型  
Anova(yreg,type=2)    ## "type=2"显示无交互效应协方差分析模型


yreg<-lm(Y~x1+x2+Z, data=data) 
lmResults<-summary(yreg)
lmResults$coefficients
coef<-yreg$coefficients  ##回归系数
s<-lmResults$sigma;       ###误差标准差
o1<-c(rep(1,15))
W=cbind(o1,data$x1,data$x2,data$Z) ###模型稀疏矩阵
round(coef,3); round(s^2,3);
round(s^2* solve(t(W)%*%W),4)  ##回归系数协方差阵

anova(yreg)  ### 模型残差平方和


yreg2<-lm( Y~Z, data=data)
anova(yreg2)  ### alpha1=alpha1=0下的残差平方和

yreg3<-lm( Y~x1+x2, data=data)
summary(yreg3)
anova(yreg3) ### gamma=0下的残差平方和

yreg4<-lm( Y~1, data=data)
anova(yreg4) ###总平方和

regression_ss <- sum(anova(yreg)["I1", "Sum Sq"])+
  sum(anova(yreg)["x2", "Sum Sq"]) +sum(anova(yreg)["Z", "Sum Sq"])##回归平方和

residuals<-residuals(yreg)
residuals_ss <- sum(residuals^2) ##或者sum(anova(yreg)["Residuals", "Sum Sq"])

1-pf(59.491, 2,11)
qf(0.95,2, 11)

###置信区间
dalta<-c(5.075,12.9768, 7.9014)
sqtvar<-c(sqrt(1.5104), sqrt(1.4534), sqrt(1.4132))
alpha=0.05
##置信区间 
daltaL<-dalta-sqtvar*qt(1-alpha/2, 11)
daltaR<-dalta+sqtvar*qt(1-alpha/2, 11)

##Scheffe同时置信区间 
daltaSL<-dalta-sqtvar*sqrt(2*qf(1-alpha, 2,11))
daltaSR<-dalta+sqtvar*sqrt(2*qf(1-alpha, 2,11))

##Bonferroni同时置信区间 
daltaBL<-dalta-sqtvar*qt(1-alpha/4, 11)
daltaBR<-dalta+sqtvar*qt(1-alpha/4, 11)

C<-cbind(daltaL,daltaR,daltaSL,daltaSR, daltaBL,daltaBR)
round(C,3) 

###平行性检验
yreg4<-lm(Y~A+Z+A*Z, data=data) 
anova(yreg4)

