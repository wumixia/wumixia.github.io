## 8.1节图


################## 图8.1.1 ##################

# 导入数据集
# data <- read.table("/Users/macbook/Desktop/线性模型例题/Chapter8/data/表8.1.1.txt")


# 手动构建数据框
data <- data.frame(
  促销策略 = rep(1:3, each = 5),  # 3种策略，各5家店
  商店 = rep(1:5, 3),             # 5家店重复3次
  y_ij = c(38, 39, 36, 45, 33,    # 促销期销量（y_ij）
           43, 38, 38, 27, 34, 
           24, 32, 31, 21, 28),  
  x_ij = c(21, 26, 22, 28, 19,    # 促销前销量（x_ij）
           34, 26, 29, 18, 25, 
           23, 29, 30, 16, 29)
)

# 加载所需包
library(ggplot2)
library(gridExtra)



## 图8.1.1(a) 方差分析模型的误差变异性图
# 自定义主题
custom_theme <- theme(
  panel.grid = element_blank(),  # 去除所有网格
  panel.background = element_rect(fill = "white", color = "black", linewidth = 0.7),  # 白色背景+黑色边框
  panel.border = element_rect(fill = NA, color = "black", linewidth = 0.7),  # 四周边框
  plot.title = element_text(hjust = 0.5)  # 标题居中
)

# 生成三个子图（分别设置不同y轴间隔和范围）
plot_list <- lapply(1:3, function(strategy) {
  sub_data <- subset(data, 促销策略 == strategy)
  mean_val <- mean(sub_data$y_ij)
  
  # 根据不同策略设置y轴参数
  if (strategy == 1) {
    # 方案1：范围34~44，间隔2
    y_breaks <- seq(34, 44, by = 2)
    y_limits <- c(34, 44)
  } else if (strategy == 2) {
    # 方案2：范围30~40，间隔5
    y_breaks <- seq(25, 45, by = 5)
    y_limits <- c(25, 45)
  } else {
    # 方案3：范围22~32，间隔2
    y_breaks <- seq(22, 32, by = 2)
    y_limits <- c(22, 32)
  }
  ggplot(sub_data, aes(x = factor(商店), y = y_ij)) +  
    geom_point(size = 1.5, color = "black") +  
    geom_hline(yintercept = mean_val, color = "gray", linewidth = 0.7) +  
    scale_x_discrete(limits = as.character(1:5)) +  # x轴固定显示1-5
    scale_y_continuous(
      breaks = y_breaks,  # 应用对应策略的刻度间隔
      limits = y_limits   # 应用对应策略的显示范围
    ) +
    labs(
      title = paste0("方案 ", strategy),
      x = "商店", 
      y = "促销期销量"
    ) +
    custom_theme
})
# 拼接子图
grid.arrange(grobs = plot_list, ncol = 3, top = "方差分析模型的误差变异性")


## 图8.8.1(b) 协方差分析模型的误差变异性图
# 按促销策略分组提取数据
y1 <- subset(data, 促销策略 == 1)$y_ij
y2 <- subset(data, 促销策略 == 2)$y_ij
y3 <- subset(data, 促销策略 == 3)$y_ij

X1 <- subset(data, 促销策略 == 1)$x_ij
X2 <- subset(data, 促销策略 == 2)$x_ij
X3 <- subset(data, 促销策略 == 3)$x_ij

model1 <- lm(y1 ~ X1) # 对方案1进行回归分析
model2 <- lm(y2 ~ X2) # 对方案2进行回归分析
model3 <- lm(y3 ~ X3) # 对方案3进行回归分析
cat("\n===== 方案3的线性回归分析结果 =====", "\n")
regression_summary <- data.frame(
  方案 = c("方案1", "方案2", "方案3"),
  截距 = c(coef(model1)[1], coef(model2)[1], coef(model3)[1]),
  斜率 = c(coef(model1)[2], coef(model2)[2], coef(model3)[2])
)
intercepts <- regression_summary$截距  # 三组截距
slopes <- regression_summary$斜率      # 三组斜率

# 生成回归线的x序列（修正语法错误并扩展范围）
x_range <- seq(
  min(c(X1, X2, X3)) - 2,  # 修正原代码中的语法错误min(...)，向左扩展2
  max(c(X1, X2, X3)) + 4,  # 向右扩展4，确保37在范围内
  by = 1
)

# 计算每组回归线的y值
y_pred1 <- intercepts[1] + slopes[1] * x_range  # 方案1回归线
y_pred2 <- intercepts[2] + slopes[2] * x_range  # 方案2回归线
y_pred3 <- intercepts[3] + slopes[3] * x_range  # 方案3回归线

# 调整边距，避免标签被截断
par(mar = c(5, 7, 4, 2) + 0.5)  # 适度增加边距

# 初始化画布
plot(
  x = c(X1, X2, X3), y = c(y1, y2, y3),
  xlim = range(x_range) + c(-1, 1),  # 匹配x_range范围
  ylim = range(c(y1, y2, y3, y_pred1, y_pred2, y_pred3)) + c(-3, 6),  # 扩大y轴上方空间
  xlab = "促销前销量", ylab = "促销期销量",
  main = "协方差分析模型的误差变异性",
  type = "n",  # 先不绘制点
  bty = "l"    # L型边框
)

# 绘制回归线（折线图）
lines(x_range, y_pred1, col = "black", lwd = 2)   # 方案1回归线（黑色）
text(37, max(y_pred1) + 1, "方案 1", cex = 1.2)  # 微调y位置，避免重叠
lines(x_range, y_pred2, col = "red", lwd = 2)     # 方案2回归线（红色）
text(37, max(y_pred2) + 1, "方案 2", cex = 1.2)
lines(x_range, y_pred3, col = "purple", lwd = 2)  # 方案3回归线（紫色）
text(37, max(y_pred3) + 1, "方案 3", cex = 1.2)

# 绘制散点（按组区分形状和颜色）
points(X1, y1, pch = 1, col = "black", cex = 1.2)   # 方案1：空心圆
points(X2, y2, pch = 15, col = "red", cex = 1.2)     # 方案2：红色方块
points(X3, y3, pch = 24, col = "purple", cex = 1.2)  # 方案3：紫色三角

# 调整坐标轴刻度，匹配扩展后的范围
axis(side = 1, at = seq(10, 40, 10))  # x轴刻度覆盖10-40
axis(side = 2, at = seq(15, 55, 10), las = 1)  # y轴刻度水平显示，更易读


################## 图8.1.2 ##################
X<- c(0.3837194, 0.8247204, 1.5871982, 1.8198866, 2.0470306, 2.1349811, 2.3157819,
      2.3751506, 2.5222127, 2.7113610, 2.7466064, 2.7605900, 2.7913749, 2.8325762,
      2.9039920, 2.9612716, 2.9922262, 2.9924093, 3.1804957, 3.2187998, 3.5764751,
      3.7377815, 4.2373691, 4.4064394)
X1<-c(X[1:11],X[13])
X2<-c(X[14:24],X[12])
y1<-c(6.674552,  6.978161,  7.012018,  8.823354, 10.495566, 11.174188, 
      8.211577, 8.950887,  7.229183,  9.580249, 11.214000, 10.074980)
y2<-c(11.523890, 13.093616, 12.092551, 12.288981,  9.858477, 11.198065,
      12.064179, 12.709774, 13.506231, 12.249904, 13.520455, 10.151705)

## 图8.1.2(a)
# 绘制箱线图
par(ann = FALSE, mar = c(5, 5, 4, 2) + 0.1)  # 关闭自动标签，调整边距
boxplot(
  y ~ A, 
  col = "skyblue", 
  main = "两组学员成绩的Box图",
  yaxt = 'n',  # 隐藏默认y轴刻度
  xlab = "", ylab = "",  # 清空默认标签
  boxwex = 0.6  # 调整箱体宽度
)
axis(side = 2, at = seq(6, 14, by = 2), las = 1) # 添加y轴刻度
title(
  ylab = expression(italic(y)),  # y轴标签设为斜体
  xlab = expression(italic(A)),  # x轴标签设为斜体
  line = 2.5  # 调整标签与坐标轴的距离
)
aov.y<-aov(y~A)
summary(aov.y)


## 图8.1.2(b)
plot(X1, y1,lwd=3, bty = 'l', las = 1, xaxt='n',yaxt='n', xlab = "", ylab = "", xlim=c(0,5), ylim=c(5,15),  pch=1)
par(new=TRUE)
plot(X2, y2,lwd=3, bty = 'l',col='red', xaxt='n', yaxt='n', xlab = "", ylab = "", xlim=c(0,5), ylim=c(5,15),  pch=15)

text(5,5, expression(italic(paste(X))), cex=1)
text(0,15.3,expression(italic(paste(Y))), cex=1)
legend(list(x=3.2,y=7), #"topright",              #图例位置为右上角
       legend=c("方法 1","方法 2"),        #图例内容
       col=c("black","red" ),                 #图例颜色
       pch=c(1,15),
       y.intersp = 1.3 )   
title( ylab = "成绩",
       xlab = "学习时间",
       main="两组学员学习时间和成绩的散点图",
       font.main=1.1, line=1)


