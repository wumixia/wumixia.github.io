## 7.5节例题


################## 例7.5.1 ##################
#data <- read.table("/Users/macbook/Desktop/线性模型例题/Chapter7/data/例7.5.1.txt",header=TRUE)
y1<-c( 1073, 1058,1071,1037, 1066, 1026,1053, 1049,1065, 1051)
y2<-c( 1016,1058, 1038,1042,1020, 1045, 1044, 1061, 1034,1049)
y3<-c(1084, 1069, 1106, 1078, 1075, 1090,1079,1094,1111, 1092)
y <- c(y1,y2,y3)
A<-factor(gl(3,10,30))
lm.reg<-lm(y~A)
y.res = residuals(lm.reg); y.res   # 残差
### 由残差构造独立等方差序列
n1<-length(y1); n2<-length(y2);n3<-length(y3)
z1<-c(rep(0,n1-1));z2<-c(rep(0,n2-1));z3<-c(rep(0,n3-1)) 
s1<-0;s2<-0;s3<-0
for (l in 1:(n1-1)){
  s1<-s1+ y1[l]
  z1[l]=(s1/l-y1[l+1])*sqrt(l/(l+1))}

for (l in 1:(n2-1)){
  s2<-s2+ y2[l]
  z2[l]=(s2/l-  y2[l+1])*sqrt(l/(l+1))}

for (l in 1:(n3-1)){
  s3<-s3+ y3[l]
  z3[l]=(s3/l-  y3[l+1])*sqrt(l/(l+1))}
z<-c(z1,z2,z3) # 残差的独立变化 

##  Shapiro-Wilk 法
shapiro.test(y.res)

## 分别基于残差和z的Q-Q图
par(ann=FALSE, mfrow=c(1,2)) 
plot(lm.reg, 2,plot.it = TRUE, datax = FALSE, lwd = 2) ##残差的Q-Q图
title(
  xlab = "理论分位数",  
  ylab = "样本分位数",  
  cex.lab = 1.1,         # 标签字体大小
  line = 2.5
)
qqnorm(z, plot.it = TRUE, datax = FALSE, lwd = 2)
title(
  xlab = "理论分位数",  
  ylab = "样本分位数",  
  cex.lab = 1.1,         # 标签字体大小
  line = 2.5
)
abline(mean(z), sd(z), col = 2, lwd = 2) #独立等方差数据z的Q-Q图


## 方差齐性检验
install.packages("car")
library(car)
leveneTest(y.res, A, center = mean) # leveneTest检验

L<-abs(y.res) 
aovl<-aov(L~A)
summary(aovl)

## Brown-Forsythe test
d1<-abs(y1-median(y1))
d2<-abs(y2-median(y2))
d3<-abs(y3-median(y3))
d<-c(d1,d2,d3)
aovd<-aov(d~A)
summary(aovd)

## Harley最大F比法
install.packages("SuppDists")
library(SuppDists)
ms1<-var(y1); ms2<-var(y2); ms3<-var(y3)
ms1;ms2;ms3
Fmax<-max(ms1,ms2,ms3)/min(ms1,ms2,ms3)
Fmax
q<-qmaxFratio(p=0.95, df=c(3,9), 3, lower.tail=TRUE, log.p=FALSE)  # F_{max}的分位数
round(c(Fmax, q[2], 2)) # 保留两位小数


## bartlett.test
bartlett.test(y, A)

## 绘制Box图
# 合并为数据框用于绘制Box图
data <- data.frame(
  value = c(y1, y2, y3),
  group = factor(rep(c("y1", "y2", "y3"), each = 10))
)
# 计算两两组差
diff_y1y2 <- y1 - y2
diff_y2y3 <- y2 - y3
diff_y3y1 <- y3 - y1
# 合并组差数据
diff_data <- data.frame(
  difference = c(diff_y1y2,diff_y2y3,diff_y3y1),
  pair = factor(rep(c("y1-y2","y2-y3","y3-y1"), each = 10))
)
# 设置图形布局
par(mfrow = c(1, 2), mar = c(5, 4, 2, 2) + 0.1)
# 假设前面已定义data和diff_data数据框

# 绘制三组数据的Box图
boxplot(value ~ group, data = data,
        main = "三组数据的Box图",
        xlab = expression(italic(A)), ylab = expression(italic(y)),
        col = c("#FF9999", "#66B2FF", "#99FF99"),
        border = "black",
        names = c("1", "2", "3")  # 自定义第一组Box图的横坐标标签
)
# 绘制两两组差的Box图
boxplot(difference ~ pair, data = diff_data,
        main = "两两组差数据的Box图",
        xlab = "配对组", ylab = "对照",
        col = c("#FFCC99", "#CC99FF", "#99CCFF"),
        border = "black",
        names = c("1-2", "2-3", "3-1")  # 自定义第二组Box图的横坐标标签
)


### 方差分析
A<-factor(gl(3,10,30))
y.aov <- aov(y~A) 
summary(y.aov)



MSe=(ms1*(n1-1)+ms2*(n2-1)+ms3*(n3-1))/(n1+n2+n3-3)
c=1+(1/(n1-1)+1/(n2-1)+1/(n3-1)-1/(length(y)-1))/(3*(3-1))
B=((length(y)-3)*log(MSe)-(n1-1)*log(ms1)-(n2-1)*log(ms2)-(n3-1)*log(ms3))/c


#######pairwise confindence interval
t025<-qt(0.975,df=27)      #2.051831
t0083<-qt((1-0.025/3),df=27)  #2.552459
f05<-qf(0.95,2,27)           #3.354131
q05<-qtukey(0.95, 3, 27) # 3.506426

hatmu<-c(mean(y1),mean(y2),mean(y3))
q<-c(qt(0.975,df=27),qt((1-0.025/3),df=27),qf(0.95,2,27) , qtukey(0.95, 3, 27))
C<-matrix(0,3,8)
delta<-c(hatmu[1]-hatmu[2], hatmu[2]-hatmu[3], hatmu[3]-hatmu[1])
dd<-c(sqrt(2)*q[1], sqrt(2)*q[2], sqrt(4 *q[3]), q[4])*sqrt(MSe/10)
for (i in 1:3){
  for (j in 1:4){
    C[i,(2*j-1)]<- delta[i]-dd[j] 
    C[i,(2*j)]<- delta[i]+dd[j] 
  }} 
round(C,3)
