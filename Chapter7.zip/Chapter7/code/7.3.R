
## 7.3节例题


################## 例7.3.1 ##################
# 导入数据集
data <- read.table("/Users/macbook/Desktop/线性模型例题/Chapter7/data/例7.3.1.txt",header=TRUE )
colnames(data)<- c("y","A","B")
y.aov <- aov(y~A+B+A:B, data=data) 
summary(y.aov)

# 手动输入
y <- c(130,155,174,180,34,40,80,75,20,70,82,58,150,188,159,126,136,122,106,115,25,70,58,45,138,110,168,160,174,120,150,139,96,104,82,60)
A <- factor(gl(3,12,36))
B <- factor(gl(3,4,36))

y.aov <- aov(y~A+B+A:B)##或 aov(y~A*B)
summary(y.aov)

y.aov <- aov(y~B+A+A*B)  ###平衡换序无影响
summary(y.aov)

install.packages("car")
library(car)

###不平衡下
r<-c(1,2,5,6,9)  # 删除5项，转为不平衡
y<-y[-r]
A <-A[-r]     
B<- B[-r]       #对应的因子
###########################应用函数 Anova(, type =3 )
ylm<- lm(y~A*B)
Anova(ylm, type =3)### 

####################################手动回归程序
n<- length(y)
o1<-c(rep(1,n)) 
A1<-c(rep(0,n)); A1[A==3]<- -1; A1[A==1]<- 1;
A2<-c(rep(0,n)); A2[A==3]<- -1; A2[A==2]<- 1;
B1<-c(rep(0,n)); B1[B==3]<- -1; B1[B==1]<- 1;
B2<-c(rep(0,n)); B2[B==3]<- -1; B2[B==2]<- 1;
A1B1<-A1*B1
A2B1<-A2*B1
A1B2<-A1*B2
A2B2<-A2*B2

ylm<- lm(y~A1+A2+ B1+B2+A1B1+A2B1+ A1B2+A2B2)
SSE<- sum(anova(ylm)["Residuals", "Sum Sq"]) #全模型残差
ylmA<- lm(y~B1+B2+A1B1+A2B1+ A1B2+A2B2)
SSE_A<- sum(anova(ylmA)["Residuals", "Sum Sq"]) 
SSA=SSE_A-SSE                          #A因子平方和


ylmB<- lm(y~A1+A2+A1B1+A2B1+ A1B2+A2B2)
SSE_B<- sum(anova(ylmB)["Residuals", "Sum Sq"])
SSB=SSE_B-SSE                        #B因子平方和

ylmAB<- lm(y~A1+A2+ B1+B2)
SSE_AB<- sum(anova(ylmAB)["Residuals", "Sum Sq"])
SSAB=SSE_AB-SSE                       #AB因子平方和
SS<-c(SSA,SSB,SSAB,SSE)
F_A=(n-9)*SSA/(2*SSE) 
F_B=(n-9)*SSB/(2*SSE) 
F_AB=(n-9)*SSAB/(4*SSE)
df<-c(2,2,4,n-9)
F<-c(round(F_A,4), round(F_B,4),round( F_AB,4),NA)
pvalue<-  c(1- round(pf(F_A ,2, n-9),4),  1-round(pf(F_B ,2, n-9), 4),
            1-round(pf(F_AB, 4, n-9),4),NA) 
TypeIIIresult= cbind(SS,df, F, pvalue)     ###结果
rownames (TypeIIIresult) <-c('A', 'B', 'A:B', 'Residual')
TypeIIIresult



################# 例7.3.2 ###########直接采用Anova(ylm, type = "III")#######
y<-c(1.4, 2.4, 2.2, 2.1, 1.7, 0.7,  1.1,  2.4,2.5, 1.8, 2.0,0.5,0.9,1.3)
A<-factor(c(rep(1,7),rep(2,7)))
B<-factor(c(rep(1,3),rep(2,2), rep(3,2), 1, rep(2,3),rep(3,3)))
ylm<- lm(y~A*B)
library(car)
options(contrasts = c("contr.sum", "contr.poly"))
Anova(ylm, type = "III")
Anova(ylm, type = "2")
 
ylm<- lm(y~A+B)
 
Anova(ylm, type = "III")
Anova(ylm, type = "2")

################## 例7.3.2 #########手动编写#########
y<-c(1.4, 2.4, 2.2,2.1, 1.7, 0.7,  1.1, 2.4,2.5, 1.8, 2.0,0.5,0.9,1.3)
A1<-c(1,1,1, 1,1,1,1,-1,-1,-1, -1,-1,-1,-1)
B1<-c(1,1,1, 0,0,-1,-1,1,0,0, 0,-1,-1,-1)
B2<-c(0,0,0, 1,1,-1,-1,0,1,1, 1,-1,-1,-1)
A1B1<- A1*B1
A1B2<- A1*B2
n<- length(y)
ylm<- lm(y~A1+ B1+B2+A1B1+A1B2)

SSE<- sum(anova(ylm)["Residuals", "Sum Sq"]) #全模型残差
ylmA<- lm(y~B1+B2+A1B1+A1B2)
SSE_A<- sum(anova(ylmA)["Residuals", "Sum Sq"]) 
SSA=SSE_A-SSE                          #A因子平方和
ylmB<- lm(y~A1+A1B1+A1B2)
SSE_B<- sum(anova(ylmB)["Residuals", "Sum Sq"])
SSB=SSE_B-SSE                        #B因子平方和
ylmAB<- lm(y~A1+B1+B2)
SSE_AB<- sum(anova(ylmAB)["Residuals", "Sum Sq"])
SSAB=SSE_AB-SSE                       #AB因子平方和
SS<-round(c(SSA,SSB,SSAB,SSE),4)
F_A=(n-6)*SSA/(1*SSE) 
F_B=(n-6)*SSB/(2*SSE) 
F_AB=(n-6)*SSAB/(2*SSE)
df<-c(1,2,2,n-6)                  #自由度
MSS<-round(SS/df,4)               #均方
F<-c(round(F_A,4), round(F_B,4),round( F_AB,4),NA)
pvalue<-  c(1- round(pf(F_A ,1, n-6),4),  1-round(pf(F_B ,2, n-6), 4),
            1-round(pf(F_AB, 2, n-6),4),NA) 
TypeIIIresult= cbind(df, SS,MSS,F, pvalue)     ###结果
rownames (TypeIIIresult) <-c('A', 'B', 'A:B', 'Residual')
TypeIIIresult

ylmB<- lm(y~B1+B2 )
SSE_B<- sum(anova(ylmB)["Residuals", "Sum Sq"])


##### \bar{y}_{ij.}对照
Male<-c(2.0, 1.9,0.9)
Female<-c(2.4, 2.1,0.9)
x<-c(1,2,3)
## 图7.3.1
plot(Male~x, bty='l',lwd=2, type='o', xlab = "骨骼发育" , xaxt='n', ylab = " 生长率变化的样本均值", xlim=c(1,3),ylim=c(0.5,3))
axis(1,1:3, c('严重发育不良','中度发育不良','轻度发育不良'),font=2)
par(new=TRUE, mfrow=c(1,1))
plot(Female~x, bty='l', lwd=2, lty='dashed', type='o', col='red', xaxt='n', yaxt='n', xlab = "", ylab = "", xlim=c(1,3), ylim=c(0.5,3))
text(1.5, 2.5,"女孩",font=2,cex=1.5)
text(1.5,1.8,"男孩",font=2, cex=1.5)


## 交互效应不显著
install.packages("car")
library(car)
A<-factor( c(1,1,1, 1,1,1,1,2,2,2, 2,2,2,2)  )
B<-factor(c(1,1,1, 2,2,3,3,1,2,2,2,3,3,3))
ylm<- lm(y~A+B)
Anova(ylm, type=2) ## Anova()的type=2可计算无交互的主因子的精确检验

