## 7.2节例题


################## 例7.2.1 ##################
y <- c(58.2,56.2,65.3,49.1,54.1,51.6,60.1,70.9,39.2,75.8,58.2,48.7)
A <- factor(gl(4,3,12))
B <- factor(gl(3,1,12))
y.aov <- aov(y~A+B)
summary(y.aov)


xA<-c(1,2,3,4) 
xB<-c(1,2,3)
yA<-c(mean(y[A==1]), mean(y[A==2]),mean(y[A==3]),mean(y[A==4])  )
yB<-c(mean(y[B==1]), mean(y[B==2]),mean(y[B==3]))

par(mfrow = c(1,2), cex=1.2, ann=TRUE)
# 第一个图
plot(xA, yA, bty='l', type='o', lwd=2, 
     xlab = " ", xaxt='n', ylab = " ", 
     xlim=c(1,4), ylim=c(50,62),
     pch=16)  # 实心圆点
axis(1, 1:4, c('A1','A2','A3','A4'), font.axis = 3)  # 斜体横坐标
text(1, 62, expression(paste(bar(y)[i.])))
# 第二个图
plot(xB, yB, bty='l', lwd=2, type='b', lty=2, 
     pch=17, col='red',  # pch=17是实心三角形
     xlab = " ", xaxt='n', ylab = " ", 
     xlim=c(1,3), ylim=c(50,62))
axis(1, 1:3, c('B1','B2','B3'), font.axis = 3)  # 斜体横坐标
text(1, 62, expression(paste(bar(y)[.j])))







################## 例7.2.2 ##################
y <- c(63.1,63.9,65.6,66.8,65.1,66.4,67.8,69.0,67.2,71.0,71.9,73.5)
A <- factor(gl(3,4,12))
B <- factor(gl(4,1,12))
y.aov <- aov(y~A+B)       ###y.aov <- aov(y~B+A)平衡数据下
summary(y.aov)
TukeyHSD(y.aov) ### Tukey 置信区间
## 图7.2.2
par(
  mfrow = c(1, 2),  # 1行2列布局
  mar = c(5, 5, 4, 2) + 0.1,  #
  oma = c(0, 0, 2, 0),  # 外边界（底部,左,上,右），顶部留空间放总标题
  mgp = c(2, 0.8, 0),  # 坐标轴标签位置（离轴距离）
  cex.axis = 0.8  # 轴标签字体大小
)
TukeyHSD(y.aov,"A", ordered = TRUE)
plot(TukeyHSD(y.aov, "A"), las = 1)
TukeyHSD(y.aov, "B", ordered = TRUE)
plot(TukeyHSD(y.aov,"B"), las = 1)  # 画出置信区间





################## 例7.2.3 ##################
y <- c(58.2,56.2,65.3,49.1,54.1,51.6,60.1,70.9,39.2,75.8,58.2,48.7)
a<-4; b<-3; n<-a*b
A <- factor(gl(a,b,n)); B <- factor(gl(b,1,n))
y..<-c(rep(mean(y),n))
muA<-c(rep(mean(y[A==1]),b), rep(mean(y[A==2]),b), rep(mean(y[A==3]),b),
       rep(mean(y[A==4]),b))
muB<- rep(c(mean(y[B==1]), mean(y[B==2]), mean(y[B==3])),a)
SST<-sum((y-y..)*(y-y..))
SSA<-sum((muA-y..)*(muA-y..)); SSB<-sum((muB-y..)*(muB-y..))
SSab<-a*b*(sum((muA-y..)*(muB-y..)*y))^2/(SSA*SSB)
SSe<-SST-SSA-SSB-SSab
F=(n-a-b)*SSab/SSe ##检验统计量
Fq=qf(0.95,1,5); pvalue=pf(F, 1,5)
round(c(SST,SSA,SSB,SSab,SSe, F, Fq, pvalue),3)

