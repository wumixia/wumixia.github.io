## 7.1节例题


################## 例7.1.1 ##################
y <- c(12,18,14,17,13,19,17,21,24,30)
A <- factor(c(rep(1,2),rep(2,3),rep(3,3),rep(4,2)))
X.aov <- aov(y ~ A)
summary(X.aov)
n=10

## 画图
x<-c(1, 1, 2, 2, 2, 3, 3, 3, 4, 4)
plot(x,y, bty='l',lwd=2, xlab = "包装方式" , xaxt='n', ylab = " 销售量", xlim=c(1,4),ylim=c(10,30))
axis(1,1:4, c('甲','乙','丙','丁') )




################## 例7.1.2 ##################
x <- c(0.0,1.0,2.3,3.5,2.8,2.5,3.1,2.7,3.8)
A <- factor(c(rep(1,2),rep(2,4),rep(3,3)))
X <- data.frame(x,A)
X.aov <- aov(x ~ A,data = X)
summary(X.aov)
confint(X.aov,level=0.95)



