## 6.5节例题


################## 例6.5.2 ##################
data <- read.table("/Users/macbook/Desktop/线性模型例题/Chapter6/data/例6.5.2.txt",header=TRUE )
colnames(data)<- c("i","X","Y")
lm.reg <- lm(Y ~ X ,data = data)## 
summary(lm.reg) ##输出结果 
## 表6.5.2
influence.measures(lm.reg) ### 回归诊断的总结
lm.reg$residuals # 残差
hatvalues(lm.reg)
r<-rstandard(lm.reg)#标准化残差
n<-length(r);   
t<-sqrt((n-3)*r^2)/sqrt(r^2*(n-2-r^2) ) ## 异常值检验 

## 图6.5.1:模型诊断图
X<-data[,2];  Y<-data[,3]
par(ann=FALSE, mfrow=c(2,2))
plot(X,Y, pch=19)   ##散点图
title(
  xlab = expression(italic(X)),  
  ylab = expression(italic(Y)),  
  cex.lab = 1.1,        # 标签字体大小
  line = 2.5
)
abline(lm.reg, lwd=3 ) 
plot(lm.reg,1,pch=19,lwd=3 ) #绘制残差图
title(
  xlab = expression(italic(hat(y)[i])),  
  ylab = expression(italic(hat(e)[i])),  
  cex.lab = 1.1,        # 标签字体大小
  line = 2.5
)
plot(lm.reg,5,pch=19,lwd=3 ) #杠杆值和标准残差
title(
  xlab = expression(italic(h[ii])),  
  ylab = expression(italic(Y[i])),  
  cex.lab = 1.1,        # 标签字体大小
  line = 2.5
)
plot(lm.reg,4,pch=19,lwd=3  ) #cook distance
title(
  xlab = expression(italic(i)),  
  ylab = expression(italic(D[i])),  
  cex.lab = 1.1,        # 标签字体大小
  line = 2.5
)



